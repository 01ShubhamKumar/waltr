package com.waltr.waltr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaltrApplicationTests {

	@Test
	void contextLoads() {
	}

}
